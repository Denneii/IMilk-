# Ileite de Peito

**Projeto da Avaliação Prática AOO - AV2**

## Descrição
O *Ileite de Peito* é um sistema que conecta mães doadoras de leite humano a bancos de leite e motoristas que realizam as coletas. O objetivo é facilitar a logística da doação e garantir um processo seguro, eficiente e com impacto social relevante.

## Funcionalidades
- Cadastro de perfis: mãe doadora, banco de leite, motorista
- Publicação de disponibilidade de leite
- Solicitação e agendamento de coletas
- Rastreamento da entrega
- Comunicação entre os usuários
- Geração de relatórios
- Criação de campanhas de incentivo

## Diagramas UML
O projeto inclui os seguintes diagramas:
- Diagrama de Classes
- Diagrama de Componentes
- Diagrama de Arquitetura
- Diagrama de Sequência
- Diagrama de Atividades
- Diagrama de Estados

## Tecnologias sugeridas
- Java 21
- Spring Boot 3
- MySQL
- Swagger (documentação REST)
- UML Designer, Lucidchart ou Draw.io (para os diagramas)

## Equipe
- Gilberto Vieira Barreto
- Cristyan Marcos

## Instruções de uso
1. Clone o repositório
2. Importe o projeto em uma IDE Java com suporte a Maven ou Gradle
3. Configure o banco de dados MySQL com base nas instruções fornecidas (não incluídas aqui)
4. Execute a aplicação
